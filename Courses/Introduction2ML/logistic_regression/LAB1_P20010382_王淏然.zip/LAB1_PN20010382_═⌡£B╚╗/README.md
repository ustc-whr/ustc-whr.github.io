1.数据来自：**[Assignments/assignment1 at main · USTC-MLI-F23/Assignments (github.com)](https://github.com/USTC-MLI-F23/Assignments/tree/main/assignment1)**

2.模型为Logistic回归

3.加入了l1l2的正则项

4.数据处理采用了均值和按比例填补float形和object形的NaN

5.正确率可达约83%

6.个人联系方式：whr14159@mail.ustc.edu.cn

